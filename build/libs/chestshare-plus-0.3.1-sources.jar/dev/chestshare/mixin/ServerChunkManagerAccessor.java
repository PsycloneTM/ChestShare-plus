package dev.chestshare.mixin;

import net.minecraft.class_3193;
import net.minecraft.class_3215;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

// getVisibleChunkIfPresent(long) is package-private - accessor needed for ImportJob. See NOTES.md.
@Mixin(class_3215.class)
public interface ServerChunkManagerAccessor {
    @Invoker("getVisibleChunkIfPresent")
    class_3193 chestshare$getChunkHolder(long chunkPos);
}
