package dev.chestshare.mixin;

import dev.chestshare.SharedMarker;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2586.class)
public class BlockEntityMixin implements SharedMarker {
    @Unique private boolean chestshare$shared;
    @Override public boolean chestshare$isShared(){return chestshare$shared;}
    @Override public void chestshare$setShared(boolean shared){chestshare$shared=shared;}
    @Inject(method="saveAdditional",at=@At("TAIL"))
    private void chestshare$save(class_2487 tag, class_7225.class_7874 provider, CallbackInfo ci){if(chestshare$shared)tag.method_10556("chestshare:shared",true);}
    @Inject(method="loadAdditional",at=@At("TAIL"))
    private void chestshare$load(class_2487 tag, class_7225.class_7874 provider, CallbackInfo ci){chestshare$shared=tag.method_10577("chestshare:shared");}
}
