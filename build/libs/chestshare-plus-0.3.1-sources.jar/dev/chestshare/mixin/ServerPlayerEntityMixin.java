package dev.chestshare.mixin;

import dev.chestshare.open.SharedContainerOpener;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin {
    @ModifyVariable(method="openMenu",at=@At("HEAD"),argsOnly=true)
    private class_3908 chestshare$redirect(class_3908 provider){return SharedContainerOpener.replaceFactory((class_3222)(Object)this,provider);}
}
