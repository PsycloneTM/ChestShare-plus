package dev.chestshare.mixin;

import dev.chestshare.ContainerRegistrar;
import dev.chestshare.open.SharedContainerOpener;
import dev.chestshare.state.SharedContainerEntry;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3218;
import net.minecraft.class_3908;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2281.class)
public abstract class ChestBlockMixin {
    @Inject(method="getMenuProvider", at=@At("RETURN"), cancellable=true)
    private void chestshare$redirect(class_2680 state, class_1937 level, class_2338 pos, CallbackInfoReturnable<class_3908> cir){
        if (!(level instanceof class_3218 world)) return;
        if (!(world.method_8321(pos) instanceof class_2595 primary)) return;

        // Lazy registration on open, not CHUNK_GENERATE scan - see NOTES.md
        if (state.method_11654(class_2281.field_10770) == class_2745.field_12569) {
            SharedContainerEntry entry = SharedContainerOpener.resolveBlockEntry(world, primary);
            if (entry != null) {
                cir.setReturnValue(SharedContainerOpener.blockContainerFactory(
                        world, pos, entry, primary));
            }
            return;
        }

        class_2350 dir = class_2281.method_9758(state);
        class_2338 other = pos.method_10093(dir);
        if (!(world.method_8321(other) instanceof class_2595 secondary)) return;

        SharedContainerEntry first = SharedContainerOpener.resolveBlockEntry(world, primary);
        SharedContainerEntry second = SharedContainerOpener.resolveBlockEntry(world, secondary);
        if (first == null && second == null) return;
        if (first == null) first = ContainerRegistrar.registerForced(world, primary);
        if (second == null) second = ContainerRegistrar.registerForced(world, secondary);

        boolean primaryIsLeft = state.method_11654(class_2281.field_10770) == class_2745.field_12574;
        class_2338 firstPos = primaryIsLeft ? pos : other;
        class_2338 secondPos = primaryIsLeft ? other : pos;
        SharedContainerEntry firstEntry = primaryIsLeft ? first : second;
        SharedContainerEntry secondEntry = primaryIsLeft ? second : first;
        cir.setReturnValue(SharedContainerOpener.doubleChestFactory(
                world, firstPos, secondPos, firstEntry, secondEntry));
    }

}
