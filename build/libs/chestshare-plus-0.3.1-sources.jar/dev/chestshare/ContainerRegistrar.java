package dev.chestshare;

import dev.chestshare.state.ContainerTemplate;
import dev.chestshare.state.SharedContainerEntry;
import dev.chestshare.state.SharedContainersState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2621;
import net.minecraft.class_3218;

public final class ContainerRegistrar {
    private ContainerRegistrar() {}
    public static SharedContainerEntry register(class_3218 world, class_2621 container) { return register(world, container, true); }
    public static SharedContainerEntry register(class_3218 world, class_2621 container, boolean markDirty) {
        // Order matters here - see NOTES.md
        var lootTable = container.method_54869();
        ContainerTemplate template;

        if (lootTable != null) {
            template = new ContainerTemplate.LootTableTemplate(
                    lootTable.method_29177(),
                    container.method_54870(),
                    container.method_5439());
        } else {
            List<class_1799> held = copyContents(container);
            boolean empty = held.stream().allMatch(class_1799::method_7960);
            if (empty) return null;
            template = new ContainerTemplate.ItemListTemplate(held, container.method_5439());
        }

        return applyTemplate(world, container, template, markDirty);
    }
    public static SharedContainerEntry registerForced(class_3218 world, class_2621 container) {
        return applyTemplate(world, container, new ContainerTemplate.ItemListTemplate(copyContents(container), container.method_5439()));
    }
    public static SharedContainerEntry applyTemplate(class_3218 world, class_2621 container, ContainerTemplate template) { return applyTemplate(world, container, template, true); }
    public static SharedContainerEntry applyTemplate(class_3218 world, class_2621 container, ContainerTemplate template, boolean markDirty) {
        // Order matters here - see NOTES.md
        container.method_11285(null);
        container.method_54866(0L);
        for (int i=0;i<container.method_5439();i++) {
            container.method_5447(i, class_1799.field_8037);
        }
        ((SharedMarker)container).chestshare$setShared(true);
        if (markDirty) container.method_5431();
        SharedContainerEntry entry = new SharedContainerEntry(template);
        SharedContainersState.get(world).putBlock(container.method_11016(), entry);
        ChestShare.LOGGER.debug("Registered shared container at {} in {}", container.method_11016(), world.method_27983().method_29177());
        return entry;
    }
    public static List<class_1799> copyContents(class_1263 container) {
        List<class_1799> out = new ArrayList<>(container.method_5439());
        for (int i=0;i<container.method_5439();i++) out.add(container.method_5438(i).method_7972());
        return out;
    }
}
