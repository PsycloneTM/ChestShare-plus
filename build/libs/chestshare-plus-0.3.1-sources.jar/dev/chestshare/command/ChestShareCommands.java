package dev.chestshare.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.chestshare.ContainerRegistrar;
import dev.chestshare.SharedMarker;
import dev.chestshare.compat.ContainerCompatibility;
import dev.chestshare.state.ContainerTemplate;
import dev.chestshare.state.SharedContainerEntry;
import dev.chestshare.state.SharedContainersState;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2232;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2621;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public final class ChestShareCommands {
    private ChestShareCommands() {}
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("chestshare").requires(s->s.method_9259(2))
                .then(method_9247("convert").then(method_9244("pos", class_2262.method_9698()).then(method_9244("loot_table", class_2232.method_9441())
                        .suggests((context, builder) -> class_2172.method_9270(
                                context.getSource().method_9211().method_58576().method_58290(class_7924.field_50079),
                                builder))
                        .executes(c->convert(c.getSource(),class_2262.method_9696(c,"pos"),class_2232.method_9443(c,"loot_table"))))))
                .then(method_9247("reset").then(method_9244("pos",class_2262.method_9698()).executes(c->reset(c.getSource(),class_2262.method_9696(c,"pos")))))
                .then(method_9247("export").then(method_9244("file",StringArgumentType.word()).executes(c->exportContainers(c.getSource(),StringArgumentType.getString(c,"file")))))
                .then(method_9247("import")
                        .then(method_9247("cancel").requires(s->ImportJob.ACTIVE!=null).executes(c->cancelImport(c.getSource())))
                        .then(method_9247("status").requires(s->ImportJob.ACTIVE!=null).executes(c->importStatus(c.getSource())))
                        .then(method_9244("file",StringArgumentType.word()).requires(s->ImportJob.ACTIVE==null)
                                .executes(c->importContainers(c.getSource(),StringArgumentType.getString(c,"file"),false,1))
                                .then(method_9244("parallel",IntegerArgumentType.integer(1,8))
                                        .executes(c->importContainers(c.getSource(),StringArgumentType.getString(c,"file"),false,IntegerArgumentType.getInteger(c,"parallel"))))
                                .then(method_9247("force")
                                        .executes(c->importContainers(c.getSource(),StringArgumentType.getString(c,"file"),true,1))
                                        .then(method_9244("parallel",IntegerArgumentType.integer(1,8))
                                                .executes(c->importContainers(c.getSource(),StringArgumentType.getString(c,"file"),true,IntegerArgumentType.getInteger(c,"parallel")))))))
        );
    }
    // Never use BlockPos.toString() for chat/log output - see NOTES.md
    private static String coordString(class_2338 pos) {
        return pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260();
    }
    // Clients cache the command tree from login (requires() is evaluated once, then baked
    // into what that client sees in tab-complete) - see NOTES.md. Must be called any time
    // ImportJob.ACTIVE changes, or cancel/status will never appear to already-connected players.
    public static void refreshCommandTrees(MinecraftServer server) {
        if (server == null) return;
        for (var player : server.method_3760().method_14571()) {
            server.method_3734().method_9241(player);
        }
    }
    private static int convert(class_2168 source, class_2338 pos, class_2960 id) {
        class_3218 world=source.method_9225(); class_2586 be=world.method_8321(pos);
        var lootTables = world.method_8503().method_58576().method_58294().method_46751(class_7924.field_50079);
        class_5321<net.minecraft.class_52> lootTableKey=class_5321.method_29179(class_7924.field_50079,id);
        if(lootTables.method_46746(lootTableKey).isEmpty()){
            source.method_9213(class_2561.method_43470("No loot table registered with ID "+id+" (check spelling / that the providing mod or datapack is loaded)."));
            return 0;
        }
        if(be instanceof class_2621 c){
            // Seed MUST be 0L here - see NOTES.md (re-convert determinism bug)
            c.method_11285(lootTableKey); c.method_54866(0L);
            SharedContainerEntry entry=ContainerRegistrar.register(world,c);
            if(entry==null){source.method_9213(class_2561.method_43470("The container has no loot table or items to share."));return 0;}
            source.method_9226(()->class_2561.method_43470("Converted container at "+coordString(pos)+" to shared loot "+id+" (previous contents discarded)"),true); return 1;
        }
        if(be!=null && ContainerCompatibility.isSupportedContainer(be)){
            ContainerCompatibility.CompatInventory inv=ContainerCompatibility.getContainerInventory(be);
            // Seed MUST be 0L here too - see NOTES.md
            ContainerTemplate template=new ContainerTemplate.LootTableTemplate(id, 0L, inv.size());
            for(int s=0;s<inv.size();s++){inv.set(s, class_1799.field_8037);}
            if(be instanceof SharedMarker marker) marker.chestshare$setShared(true);
            be.method_5431();
            SharedContainersState.get(world).putBlock(pos, new SharedContainerEntry(template));
            source.method_9226(()->class_2561.method_43470("Converted container at "+coordString(pos)+" to shared loot "+id+" (previous contents discarded)"),true); return 1;
        }
        source.method_9213(class_2561.method_43470("No lootable container at "+coordString(pos))); return 0;
    }
    private static int reset(class_2168 source, class_2338 pos) {
        class_3218 world=source.method_9225();
        SharedContainersState state=SharedContainersState.get(world);
        SharedContainerEntry entry=state.getBlock(pos);
        if(entry==null){
            source.method_9213(class_2561.method_43470("No shared container registered at "+coordString(pos)));
            return 0;
        }
        // reset() semantics - see NOTES.md
        entry.clearInstances();
        state.method_80();
        source.method_9226(()->class_2561.method_43470("Reset all player instances of the shared container at "+coordString(pos)),true);
        return 1;
    }
    private static Path resolveDataFile(MinecraftServer server,String file){if(file.contains("/")||file.contains("\\")||file.contains(".."))return null;return server.method_3831().resolve(file+".nbt");}
    private static int exportContainers(class_2168 source,String fileName){
        Path path=resolveDataFile(source.method_9211(),fileName); if(path==null){source.method_9213(class_2561.method_43470("Invalid file name (plain name only, no path)"));return 0;}
        class_2487 root=new class_2487(); root.method_10569("Version",1); class_2499 dims=new class_2499(); int count=0;
        for(class_3218 world:source.method_9211().method_3738()){
            SharedContainersState state=SharedContainersState.get(world); class_2487 dim=new class_2487(); dim.method_10582("Dimension",world.method_27983().method_29177().toString()); class_2499 blocks=new class_2499(); final int[] n={0}; state.forEachBlock((pos,e)->{class_2487 b=new class_2487();b.method_10544("Pos",pos.method_10063());b.method_10566("Template",e.template().toNbt(source.method_9211().method_30611()));blocks.add(b);n[0]++;}); if(!blocks.isEmpty()){dim.method_10566("Blocks",blocks);dims.add(dim);count+=n[0];}
        }
        root.method_10566("Dimensions",dims); try{class_2507.method_30614(root,path);}catch(IOException e){source.method_9213(class_2561.method_43470("Export failed: "+e.getMessage()));return 0;}
        final int exportedCount=count; final Path exportedPath=path; source.method_9226(()->class_2561.method_43470("Exported "+exportedCount+" shared containers to "+exportedPath),true);return exportedCount;
    }
    private static int importContainers(class_2168 source,String fileName,boolean force,int parallel){
        Path path=resolveDataFile(source.method_9211(),fileName);if(path==null){source.method_9213(class_2561.method_43470("Invalid file name (plain name only, no path)"));return 0;}
        class_2487 root;try{root=class_2507.method_30613(path,new net.minecraft.class_2505(64L*1024L*1024L, 16));}catch(IOException e){source.method_9213(class_2561.method_43470("Import failed: "+e.getMessage()));return 0;}
        if(ImportJob.ACTIVE!=null){source.method_9213(class_2561.method_43470("An import is already running"));return 0;}

        Map<class_3218,Map<Long,List<ImportJob.PendingPos>>> byChunk=new LinkedHashMap<>();
        int positionCount=0, preSkippedShared=0, preSkippedMissing=0;
        class_2499 dims=root.method_10554("Dimensions",10);
        for(int d=0;d<dims.size();d++){
            class_2487 dim=dims.method_10602(d);
            class_3218 world=ImportJob.resolveWorld(source.method_9211(),dim.method_10558("Dimension"));
            class_2499 blocks=dim.method_10554("Blocks",10);
            // Unresolvable dimension - see NOTES.md
            if(world==null){preSkippedMissing+=blocks.size();continue;}
            SharedContainersState state=SharedContainersState.get(world);
            Map<Long,List<ImportJob.PendingPos>> worldChunks=byChunk.computeIfAbsent(world,w->new LinkedHashMap<>());
            for(int i=0;i<blocks.size();i++){
                class_2487 b=blocks.method_10602(i);
                class_2338 pos=class_2338.method_10092(b.method_10537("Pos"));
                if(state.getBlock(pos)!=null){preSkippedShared++;continue;}
                long chunkKey=class_1923.method_8331(pos.method_10263()>>4,pos.method_10260()>>4);
                worldChunks.computeIfAbsent(chunkKey,k->new ArrayList<>()).add(new ImportJob.PendingPos(pos,b.method_10562("Template")));
                positionCount++;
            }
        }

        Deque<ImportJob.ChunkWork> queue=new ArrayDeque<>();
        for(Map.Entry<class_3218,Map<Long,List<ImportJob.PendingPos>>> worldEntry:byChunk.entrySet()){
            class_3218 world=worldEntry.getKey();
            for(Map.Entry<Long,List<ImportJob.PendingPos>> chunkEntry:worldEntry.getValue().entrySet()){
                class_1923 chunkPos=new class_1923(chunkEntry.getKey());
                queue.add(new ImportJob.ChunkWork(world,chunkPos,chunkEntry.getValue()));
            }
        }

        int chunkCount=queue.size();
        ImportJob job=new ImportJob(queue,force,parallel,preSkippedShared,preSkippedMissing,source);
        ImportJob.ACTIVE=job;
        refreshCommandTrees(source.method_9211());
        int effectiveParallel=job.parallelism();
        final int finalPositionCount=positionCount, finalPreSkippedShared=preSkippedShared;
        source.method_9226(()->class_2561.method_43470("Import started: "+finalPositionCount+" positions across "+chunkCount
                +" chunks ("+finalPreSkippedShared+" pre-skipped as already shared), parallel "+effectiveParallel
                +", processed in background via async chunk loading; progress in server log"),true);
        return positionCount;
    }
    private static int cancelImport(class_2168 source){
        ImportJob job=ImportJob.ACTIVE;
        if(job==null){source.method_9213(class_2561.method_43470("No import running"));return 0;}
        job.cancel(source.method_9211());
        return 1;
    }
    private static int importStatus(class_2168 source){
        ImportJob job=ImportJob.ACTIVE;
        if(job==null){source.method_9226(()->class_2561.method_43470("No import running"),false);return 0;}
        String status="Import running: "+job.processed()+"/"+job.total()+" positions, "+job.converted()+" converted, in-flight "+job.inFlightCount()+" chunks, parallel "+job.parallelism();
        source.method_9226(()->class_2561.method_43470(status),false);
        return 1;
    }
}
