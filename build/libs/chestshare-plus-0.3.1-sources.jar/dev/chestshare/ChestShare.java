package dev.chestshare;

import dev.chestshare.command.ChestShareCommands;
import dev.chestshare.command.ImportJob;
import dev.chestshare.compat.ContainerCompatibility;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1263;
import net.minecraft.class_1269;
import net.minecraft.class_2281;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2621;
import net.minecraft.class_2745;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import dev.chestshare.state.SharedContainerEntry;
import dev.chestshare.state.SharedContainersState;
import dev.chestshare.open.SharedContainerOpener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChestShare implements ModInitializer {
    public static final String MOD_ID = "chestshare";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final Queue<ScanRequest> PENDING_SCANS = new ConcurrentLinkedQueue<>();
    private static final java.util.concurrent.atomic.AtomicInteger PENDING_COUNT = new java.util.concurrent.atomic.AtomicInteger();
    // See NOTES.md: FRESHLY_GENERATED_CHUNKS
    private static final java.util.Set<Long> FRESHLY_GENERATED_CHUNKS =
            java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<>());

    private record ScanRequest(net.minecraft.class_3218 world, class_2818 chunk) {}

    @Override
    public void onInitialize() {
        // See NOTES.md: CHUNK_GENERATE registration
        ServerChunkEvents.CHUNK_GENERATE.register((world, chunk) -> {
            FRESHLY_GENERATED_CHUNKS.add(chunk.method_12004().method_8324());
        });

        ServerChunkEvents.CHUNK_LOAD.register((world, chunk) -> {
            if (world instanceof net.minecraft.class_3218 serverWorld) {
                PENDING_SCANS.add(new ScanRequest(serverWorld, chunk));
                PENDING_COUNT.incrementAndGet();
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int backlog = PENDING_COUNT.get();
            int budget = Math.max(4, Math.min(backlog, 200));
            int processed = 0;
            ScanRequest request;
            while (processed < budget && (request = PENDING_SCANS.poll()) != null) {
                PENDING_COUNT.decrementAndGet();
                try {
                    class_2818 loaded = request.world().method_14178().method_21730(
                            request.chunk().method_12004().field_9181, request.chunk().method_12004().field_9180);
                    if (loaded == request.chunk()) {
                        boolean freshlyGenerated = FRESHLY_GENERATED_CHUNKS.remove(request.chunk().method_12004().method_8324());
                        ContainerScanner.scanChunk(request.world(), request.chunk(), freshlyGenerated);
                    }
                } catch (Throwable t) {
                    LOGGER.warn("Failed to scan loaded chunk {} for ChestShare", request.chunk().method_12004(), t);
                }
                processed++;
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(ImportJob::tickActive);

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!(world instanceof class_3218 sw) || !(player instanceof class_3222 sp)) return class_1269.field_5811;
            var pos = hit.method_17777();
            class_2586 be = sw.method_8321(pos);
            if (be instanceof class_2621 randomizable) {
                SharedContainerOpener.resolveBlockEntry(sw, randomizable);
                if (sw.method_8320(pos).method_26204() instanceof class_2281
                        && sw.method_8320(pos).method_11654(class_2281.field_10770) != class_2745.field_12569) {
                    var otherPos = pos.method_10093(class_2281.method_9758(sw.method_8320(pos)));
                    if (sw.method_8321(otherPos) instanceof class_2595 other) {
                        SharedContainerOpener.resolveBlockEntry(sw, other);
                    }
                }
            } else if (be instanceof class_1263 container
                    && be instanceof class_3908
                    && be instanceof SharedMarker marker
                    && !be.getClass().getName().startsWith("net.minecraft.")) {
                SharedContainerOpener.resolveGenericEntryForUse(sw, be, container);
            } else if (be != null && !be.getClass().getName().startsWith("net.minecraft.")
                    && ContainerCompatibility.isSupportedContainer(be)) {
                // See NOTES.md: reflective compat branch in UseBlockCallback
                if (SharedContainerOpener.openCompatContainerForUse(sp, sw, be)) {
                    return class_1269.field_5812;
                }
            }
            return class_1269.field_5811;
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(world instanceof class_3218 sw) || !(player instanceof class_3222 sp)) return;
            SharedContainersState s = SharedContainersState.get(sw);
            SharedContainerEntry e = s.getBlock(pos);
            if (e == null) return;
            s.removeBlock(pos);
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> ChestShareCommands.register(dispatcher));
        LOGGER.info("ChestShare initialized (lazy container discovery enabled)");
    }
}
