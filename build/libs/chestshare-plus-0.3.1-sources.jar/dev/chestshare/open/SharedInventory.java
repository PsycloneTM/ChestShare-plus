package dev.chestshare.open;

import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1277;
import net.minecraft.class_1657;

public class SharedInventory extends class_1277 {
    private final Consumer<SharedInventory> saver;
    private final Predicate<class_1657> canUse;
    private boolean seeding = true;
    public SharedInventory(int size, Consumer<SharedInventory> saver, Predicate<class_1657> canUse) { super(size); this.saver=saver; this.canUse=canUse; }
    @Override public void method_5431() { super.method_5431(); if (!seeding) saver.accept(this); }
    public void finishSeeding() { seeding=false; }
    @Override public boolean method_5443(class_1657 player) { return canUse.test(player); }
}
