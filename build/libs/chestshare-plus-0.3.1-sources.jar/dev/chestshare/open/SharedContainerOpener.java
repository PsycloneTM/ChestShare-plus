package dev.chestshare.open;

import dev.chestshare.ChestShare;
import dev.chestshare.ContainerRegistrar;
import dev.chestshare.SharedMarker;
import dev.chestshare.state.ContainerTemplate;
import dev.chestshare.state.SharedContainerEntry;
import dev.chestshare.state.SharedContainersState;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1694;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2621;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;

public final class SharedContainerOpener {
    private static final double MAX_USE_DISTANCE_SQ=64.0;
    private SharedContainerOpener() {}

    public static class_3908 replaceFactory(class_3222 player, class_3908 factory) {
        if (factory instanceof class_2586 be && be.method_10997() instanceof class_3218 world) {
            if (be instanceof class_2621 randomizable) {
                SharedContainerEntry entry=resolveBlockEntry(world,randomizable);
                if(entry!=null) return blockContainerFactory(world,randomizable.method_11016(),entry,factory);
            } else if (!be.getClass().getName().startsWith("net.minecraft.")) {
                if (factory instanceof class_1263 container) {
                    SharedContainerEntry entry=resolveGenericEntry(world,be,container);
                    if(entry!=null) return blockContainerFactory(world,be.method_11016(),entry,factory);
                } else {
                    // resolveCompatEntry only resolves an ALREADY-registered entry, never
                    // registers a new one here - see NOTES.md.
                    SharedContainerEntry entry=resolveCompatEntry(world,be);
                    if(entry!=null) return blockContainerFactory(world,be.method_11016(),entry,factory);
                }
            }
        }
        if (factory instanceof class_1694 cart && cart.method_37908() instanceof class_3218 world) {
            SharedContainerEntry entry=resolveEntityEntry(world,cart);
            if(entry!=null) return entityContainerFactory(world,cart,entry,cart);
        }
        return factory;
    }


    public static SharedContainerEntry resolveGenericEntryForUse(class_3218 world, class_2586 be, class_1263 container) {
        return resolveGenericEntry(world, be, container);
    }

    /** Opens the shared menu for a reflective-compat container directly from the
     *  block-use event. See NOTES.md. Returns true if the shared menu was opened
     *  (caller should cancel the block-use event); false if there was nothing to share. */
    public static boolean openCompatContainerForUse(class_3222 player, class_3218 world, class_2586 be) {
        SharedContainerEntry entry = resolveCompatEntry(world, be);
        if (entry == null) return false;
        class_3908 title = be instanceof class_3908 mp ? mp
                : provider(net.minecraft.class_2561.method_43471("container.chest"), (sync, inv, p) -> null);
        player.method_17355(blockContainerFactory(world, be.method_11016(), entry, title));
        return true;
    }

    /** Resolves an ALREADY-registered shared entry for the reflective-compat path - see
     *  NOTES.md. Deliberately never registers a new one: unlike vanilla containers (which
     *  have a real per-container signal, an untouched loot table, that's safe to check on
     *  open) or generic modded containers scanned via ContainerScanner (gated on
     *  freshlyGenerated), a reflective-compat container has no equivalent per-container
     *  signal, and "on open" has no way to check chunk freshness retroactively. Registering
     *  here unconditionally used to auto-convert a player's own freshly-placed Sophisticated
     *  Storage container into a shared container the first time they opened it - a real bug.
     *  Registration for these containers must only ever happen via the freshlyGenerated-gated
     *  passive scan in ContainerScanner. */
    private static SharedContainerEntry resolveCompatEntry(class_3218 world, class_2586 be) {
        SharedContainersState state = SharedContainersState.get(world);
        class_2338 pos = be.method_11016();
        SharedContainerEntry entry = state.getBlock(pos);
        boolean marked = be instanceof SharedMarker m && m.chestshare$isShared();
        if (entry != null && !marked) { state.removeBlock(pos); return null; }
        return entry;
    }

    private static SharedContainerEntry resolveGenericEntry(class_3218 world, class_2586 be, class_1263 container) {
        SharedContainersState state=SharedContainersState.get(world); class_2338 pos=be.method_11016();
        SharedContainerEntry entry=state.getBlock(pos); boolean marked=be instanceof SharedMarker m && m.chestshare$isShared();
        if(entry!=null&&!marked){state.removeBlock(pos);return null;}
        if(entry==null){
            entry=new SharedContainerEntry(new ContainerTemplate.ItemListTemplate(ContainerRegistrar.copyContents(container),container.method_5439()));
            state.putBlock(pos,entry);
            for(int i=0;i<container.method_5439();i++)container.method_5447(i,class_1799.field_8037);
            if(be instanceof SharedMarker m)m.chestshare$setShared(true);
            be.method_5431();
            ChestShare.LOGGER.debug("Registered modded shared container {} at {}",be.getClass().getName(),pos);
        }
        return entry;
    }

    public static SharedContainerEntry resolveBlockEntry(class_3218 world, class_2621 container) {
        SharedContainersState state=SharedContainersState.get(world); class_2338 pos=container.method_11016();
        SharedContainerEntry entry=state.getBlock(pos); boolean marked=((SharedMarker)container).chestshare$isShared();
        if(entry!=null&&!marked){state.removeBlock(pos);return null;}
        if(entry==null&&marked)return ContainerRegistrar.registerForced(world,container);
        if(entry==null&&container.method_54869()!=null)return ContainerRegistrar.register(world,container);
        return entry;
    }
    public static SharedContainerEntry resolveEntityEntry(class_3218 world, class_1694 cart) {
        SharedContainersState state=SharedContainersState.get(world); UUID id=cart.method_5667(); SharedContainerEntry entry=state.getEntity(id);
        if(entry==null&&cart.method_42276()!=null){
            entry=new SharedContainerEntry(new ContainerTemplate.LootTableTemplate(cart.method_42276().method_29177(),cart.method_42277(),cart.method_5439()));
            cart.method_42275(null); cart.method_42274(0L); state.putEntity(id,entry);
            ChestShare.LOGGER.debug("Registered shared chest minecart {}",id);
        }
        return entry;
    }
    public static class_3908 doubleChestFactory(class_3218 world, class_2338 primaryPos, class_2338 secondaryPos, SharedContainerEntry primary, SharedContainerEntry secondary) {
        return provider(net.minecraft.class_2561.method_43471("container.chestDouble"), (sync,inv,p)->{
            class_3222 player=(class_3222)p;
            List<class_1799> first=getOrCreateInstance(world,player,primary,class_243.method_24953(primaryPos),fallbackSeedFor(world,primaryPos),27);
            List<class_1799> second=getOrCreateInstance(world,player,secondary,class_243.method_24953(secondaryPos),fallbackSeedFor(world,secondaryPos),27);
            SharedInventory si=new SharedInventory(54,x->{primary.putInstance(player.method_5667(),copyRange(x,0,27));secondary.putInstance(player.method_5667(),copyRange(x,27,54));SharedContainersState.get(world).method_80();},viewer->stateValidBlock(world,primaryPos,primary,viewer)&&stateValidBlock(world,secondaryPos,secondary,viewer));
            for(int i=0;i<27;i++){si.method_5447(i,first.get(i).method_7972());si.method_5447(27+i,second.get(i).method_7972());} si.finishSeeding();
            return new class_1707(class_3917.field_17327,sync,inv,si,6);
        });
    }
    private static List<class_1799> copyRange(SharedInventory inv,int from,int to){List<class_1799> out=new ArrayList<>(to-from);for(int i=from;i<to;i++)out.add(inv.method_5438(i).method_7972());return out;}

    public static class_3908 blockContainerFactory(class_3218 world, class_2338 pos, SharedContainerEntry entry, class_3908 title) {
        int rows=Math.max(1,Math.min(6,(entry.template().size()+8)/9)); int size=rows*9;
        return provider(title.method_5476(), (sync,inv,p)->menu(world,pos,entry,title.method_5476(),sync,inv,p,size));
    }
    public static class_3908 entityContainerFactory(class_3218 world, class_1694 cart, SharedContainerEntry entry, class_3908 title) {
        int rows=Math.max(1,Math.min(6,(entry.template().size()+8)/9)); int size=rows*9;
        return provider(title.method_5476(), (sync,inv,p)->{
            long seed=world.method_8510()^cart.method_5667().getMostSignificantBits()^cart.method_5667().getLeastSignificantBits();
            List<class_1799> initial=getOrCreateInstance(world,(class_3222)p,entry,cart.method_19538(),seed,size);
            SharedInventory si=new SharedInventory(size,x->save(entry,p,x,world),viewer->stateValidEntity(world,cart,entry,viewer)); fill(si,initial); si.finishSeeding();
            return new class_1707(screenType(rows),sync,inv,si,rows);
        });
    }
    private static class_1703 menu(class_3218 world,class_2338 pos,SharedContainerEntry entry,net.minecraft.class_2561 title,int sync,class_1661 inv,class_1657 p,int size){
        int rows=size/9; List<class_1799> initial=getOrCreateInstance(world,(class_3222)p,entry,class_243.method_24953(pos),fallbackSeedFor(world,pos),size);
        SharedInventory si=new SharedInventory(size,x->save(entry,p,x,world),viewer->stateValidBlock(world,pos,entry,viewer)); fill(si,initial); si.finishSeeding();
        return new class_1707(screenType(rows),sync,inv,si,rows);
    }
    private static class_3908 provider(net.minecraft.class_2561 title, net.minecraft.class_1270 constructor){ return new class_3908(){public net.minecraft.class_2561 method_5476(){return title;} public class_1703 createMenu(int id,class_1661 inv,class_1657 p){return constructor.createMenu(id,inv,p);}}; }
    private static void fill(SharedInventory inv,List<class_1799> items){for(int i=0;i<inv.method_5439();i++)inv.method_5447(i,i<items.size()?items.get(i).method_7972():class_1799.field_8037);}
    private static void save(SharedContainerEntry entry,class_1657 p,SharedInventory inv,class_3218 world){entry.putInstance(p.method_5667(),ContainerRegistrar.copyContents(inv));SharedContainersState.get(world).method_80();}
    private static boolean stateValidBlock(class_3218 world,class_2338 pos,SharedContainerEntry e,class_1657 p){return SharedContainersState.get(world).getBlock(pos)==e&&p.method_5707(class_243.method_24953(pos))<=MAX_USE_DISTANCE_SQ;}
    private static boolean stateValidEntity(class_3218 world,class_1694 cart,SharedContainerEntry e,class_1657 p){return SharedContainersState.get(world).getEntity(cart.method_5667())==e&&!cart.method_31481()&&p.method_5707(cart.method_19538())<=MAX_USE_DISTANCE_SQ;}
    public static List<class_1799> getOrCreateInstance(class_3218 world,class_3222 player,SharedContainerEntry entry,class_243 origin,long fallbackSeed,int size){List<class_1799> stored=entry.getInstance(player.method_5667()); if(stored!=null){List<class_1799> out=new ArrayList<>();for(int i=0;i<size;i++)out.add(i<stored.size()?stored.get(i).method_7972():class_1799.field_8037);return out;} List<class_1799> created=entry.template().createStacks(world,origin,player,fallbackSeed,size,world.method_30349());entry.putInstance(player.method_5667(),created);SharedContainersState.get(world).method_80();return created;}
    public static int listSize(SharedContainerEntry e){return Math.max(9,Math.min(54,((e.template().size()+8)/9)*9));}
    public static long fallbackSeedFor(class_3218 world,class_2338 pos){return world.method_8412()^pos.method_10063();}
    private static class_3917<class_1707> screenType(int rows){return switch(rows){case 1->class_3917.field_18664;case 2->class_3917.field_18665;case 3->class_3917.field_17326;case 4->class_3917.field_18666;case 5->class_3917.field_18667;default->class_3917.field_17327;};}
}
