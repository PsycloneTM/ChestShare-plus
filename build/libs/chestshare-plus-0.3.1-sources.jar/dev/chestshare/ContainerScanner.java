package dev.chestshare;

import dev.chestshare.compat.ContainerCompatibility;
import dev.chestshare.open.SharedContainerOpener;
import dev.chestshare.state.SharedContainerEntry;
import net.minecraft.class_1263;
import net.minecraft.class_2586;
import net.minecraft.class_2621;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3908;

// Scans only loaded chunks, never the world-generation callback. See NOTES.md.
public final class ContainerScanner {
    private ContainerScanner() {}

    // freshlyGenerated: true only for a chunk just created by world-gen. See NOTES.md
    // for why every modded/generic branch below is gated on it.
    public static void scanChunk(class_3218 world, class_2818 chunk, boolean freshlyGenerated) {
        boolean changed = false;
        for (class_2586 be : chunk.method_12214().values()) {
            if (be instanceof SharedMarker marker && marker.chestshare$isShared()) continue;

            if (freshlyGenerated && !be.getClass().getName().startsWith("net.minecraft.")) {
                if (ContainerCompatibility.isSupportedContainer(be)) {
                    SharedContainerEntry registered = ContainerCompatibility.register(world, be, false);
                    if (registered != null) {
                        changed = true;
                        continue;
                    }
                }
            }

            if (be instanceof class_2621 randomizable) {
                if (randomizable.method_54869() != null) {
                    changed |= ContainerRegistrar.register(world, randomizable, false) != null;
                }
                continue;
            }

            if (freshlyGenerated && be instanceof class_1263 container
                    && be instanceof class_3908
                    && !be.getClass().getName().startsWith("net.minecraft.")) {
                if (!container.method_5442()) {
                    changed |= SharedContainerOpener.resolveGenericEntryForUse(world, be, container) != null;
                }
            }
        }
        if (changed) chunk.method_12008(true);
    }
}
