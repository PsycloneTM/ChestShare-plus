package dev.chestshare.state;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_7225;

public final class SharedContainerEntry {
    private final ContainerTemplate template;
    private final Map<UUID, List<class_1799>> instances = new HashMap<>();
    public SharedContainerEntry(ContainerTemplate template) { this.template = template; }
    public ContainerTemplate template() { return template; }
    public List<class_1799> getInstance(UUID id) { return instances.get(id); }
    public void putInstance(UUID id, List<class_1799> stacks) { instances.put(id, copy(stacks)); }
    public void clearInstances() { instances.clear(); }
    public class_2487 toNbt(class_7225.class_7874 registries) {
        class_2487 nbt = new class_2487();
        nbt.method_10566("Template", template.toNbt(registries));
        class_2499 list = new class_2499();
        instances.forEach((id, stacks) -> {
            class_2487 e = new class_2487();
            e.method_25927("Player", id);
            e.method_10569("Size", stacks.size());
            class_2499 items = new class_2499();
            for (int slot = 0; slot < stacks.size(); slot++) {
                class_1799 stack = stacks.get(slot);
                // Can't encode ItemStack.EMPTY - see NOTES.md
                if (stack == null || stack.method_7960()) continue;
                class_2487 item = (class_2487) stack.method_57358(registries);
                item.method_10569("Slot", slot);
                items.add(item);
            }
            e.method_10566("Items", items);
            list.add(e);
        });
        nbt.method_10566("Instances", list);
        return nbt;
    }

    public static SharedContainerEntry fromNbt(class_2487 nbt, class_7225.class_7874 registries) {
        SharedContainerEntry entry = new SharedContainerEntry(ContainerTemplate.fromNbt(nbt.method_10562("Template"), registries));
        class_2499 list = nbt.method_10554("Instances", 10);
        for (int i = 0; i < list.size(); i++) {
            class_2487 e = list.method_10602(i);
            int size = e.method_10550("Size");
            class_2499 items = e.method_10554("Items", 10);
            List<class_1799> stacks = new ArrayList<>(size);
            for (int slot = 0; slot < size; slot++) stacks.add(class_1799.field_8037);
            for (int j = 0; j < items.size(); j++) {
                class_2487 item = items.method_10602(j);
                int slot = item.method_10545("Slot") ? item.method_10550("Slot") : j;
                if (slot >= 0 && slot < size) {
                    stacks.set(slot, class_1799.method_57359(registries, item));
                }
            }
            entry.instances.put(e.method_25926("Player"), stacks);
        }
        return entry;
    }
    private static List<class_1799> copy(List<class_1799> in) { return in.stream().map(class_1799::method_7972).toList(); }
}
