package dev.chestshare.state;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiConsumer;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public class SharedContainersState extends class_18 {
    public static final String ID = "chestshare_containers";
    private final Map<class_2338, SharedContainerEntry> blocks = new HashMap<>();
    private final Map<UUID, SharedContainerEntry> entities = new HashMap<>();
    public static SharedContainersState get(class_3218 world) { return world.method_17983().method_17924(factory(), ID); }
    public SharedContainerEntry getBlock(class_2338 pos) { return blocks.get(pos); }
    public void putBlock(class_2338 pos, SharedContainerEntry entry) { blocks.put(pos.method_10062(), entry); method_80(); }
    public void removeBlock(class_2338 pos) { blocks.remove(pos); method_80(); }
    public void forEachBlock(BiConsumer<class_2338, SharedContainerEntry> consumer) { blocks.forEach(consumer); }
    public SharedContainerEntry getEntity(UUID id) { return entities.get(id); }
    public void putEntity(UUID id, SharedContainerEntry entry) { entities.put(id, entry); method_80(); }
    public void removeEntity(UUID id) { entities.remove(id); method_80(); }
    @Override public class_2487 method_75(class_2487 nbt, class_7225.class_7874 registries) {
        class_2499 bs = new class_2499(); blocks.forEach((pos,e)->{class_2487 x=new class_2487(); x.method_10544("Pos",pos.method_10063()); x.method_10566("Entry",e.toNbt(registries)); bs.add(x);}); nbt.method_10566("Blocks",bs);
        class_2499 es = new class_2499(); entities.forEach((id,e)->{class_2487 x=new class_2487(); x.method_25927("Uuid",id); x.method_10566("Entry",e.toNbt(registries)); es.add(x);}); nbt.method_10566("Entities",es); return nbt;
    }
    public static SharedContainersState fromNbt(class_2487 nbt, class_7225.class_7874 registries) {
        SharedContainersState s=new SharedContainersState(); class_2499 bs=nbt.method_10554("Blocks",10); for(int i=0;i<bs.size();i++){class_2487 x=bs.method_10602(i);s.blocks.put(class_2338.method_10092(x.method_10537("Pos")),SharedContainerEntry.fromNbt(x.method_10562("Entry"),registries));}
        class_2499 es=nbt.method_10554("Entities",10); for(int i=0;i<es.size();i++){class_2487 x=es.method_10602(i);s.entities.put(x.method_25926("Uuid"),SharedContainerEntry.fromNbt(x.method_10562("Entry"),registries));} return s;
    }
    private static class_18.class_8645<SharedContainersState> factory() {
        return new class_18.class_8645<>(SharedContainersState::new, SharedContainersState::fromNbt, null);
    }
}
