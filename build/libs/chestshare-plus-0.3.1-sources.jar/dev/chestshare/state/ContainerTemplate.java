package dev.chestshare.state;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_173;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_52;
import net.minecraft.class_7225;
import net.minecraft.class_8567;

public sealed interface ContainerTemplate permits ContainerTemplate.LootTableTemplate, ContainerTemplate.ItemListTemplate {
    int size();
    class_2487 toNbt(class_7225.class_7874 registries);
    List<class_1799> createStacks(class_3218 world, class_243 origin, class_3222 player, long fallbackSeed, int listSize, class_7225.class_7874 registries);

    static ContainerTemplate fromNbt(class_2487 nbt, class_7225.class_7874 registries) {
        String type = nbt.method_10558("Type");
        return switch (type) {
            case "loot_table" -> new LootTableTemplate(class_2960.method_60654(nbt.method_10558("LootTable")), nbt.method_10537("Seed"), nbt.method_10550("Size"));
            case "items" -> {
                int size = nbt.method_10550("Size");
                class_2499 list = nbt.method_10554("Items", 10);
                List<class_1799> items = new ArrayList<>(size);
                for (int i = 0; i < size; i++) items.add(class_1799.field_8037);
                for (int i = 0; i < list.size(); i++) {
                    class_2487 entry = list.method_10602(i);
                    int slot = entry.method_10545("Slot") ? entry.method_10550("Slot") : i;
                    if (slot >= 0 && slot < size) {
                        items.set(slot, class_1799.method_57359(registries, entry));
                    }
                }
                yield new ItemListTemplate(items, size);
            }
            default -> throw new IllegalStateException("Unknown container template type: " + type);
        };
    }

    record LootTableTemplate(class_2960 lootTable, long seed, int size) implements ContainerTemplate {
        @Override public class_2487 toNbt(class_7225.class_7874 registries) {
            class_2487 nbt = new class_2487();
            nbt.method_10582("Type", "loot_table");
            nbt.method_10582("LootTable", lootTable.toString());
            nbt.method_10544("Seed", seed);
            nbt.method_10569("Size", size);
            return nbt;
        }

        @Override public List<class_1799> createStacks(class_3218 world, class_243 origin, class_3222 player, long fallbackSeed, int listSize, class_7225.class_7874 registries) {
            List<class_1799> out = new ArrayList<>(listSize);
            for (int i = 0; i < listSize; i++) out.add(class_1799.field_8037);
            // Must look up via server.reloadableRegistries(), not world.registryAccess() -
            // see NOTES.md (this was a real "container permanently empty" bug).
            class_52 table;
            var holder = world.method_8503().method_58576().method_58294()
                    .method_46751(net.minecraft.class_7924.field_50079)
                    .method_46746(net.minecraft.class_5321.method_29179(net.minecraft.class_7924.field_50079, lootTable));
            if (holder.isEmpty()) return out;
            table = holder.get().comp_349();
            class_8567 params = new class_8567.class_8568(world)
                    .method_51874(class_181.field_24424, origin)
                    .method_51874(class_181.field_1226, player)
                    .method_51871(player.method_7292())
                    .method_51875(class_173.field_1179);
            // Must use fill() against a scratch container, not getRandomItems() - see
            // NOTES.md (this was a real "loot packed at the start" bug).
            net.minecraft.class_1277 buffer = new net.minecraft.class_1277(listSize);
            table.method_329(buffer, params, seed != 0L ? seed : fallbackSeed);
            for (int i = 0; i < listSize; i++) out.set(i, buffer.method_5438(i).method_7972());
            return out;
        }
    }

    record ItemListTemplate(List<class_1799> items, int size) implements ContainerTemplate {
        public ItemListTemplate { items = items.stream().map(class_1799::method_7972).toList(); }
        @Override public class_2487 toNbt(class_7225.class_7874 registries) {
            class_2487 nbt = new class_2487();
            nbt.method_10582("Type", "items");
            nbt.method_10569("Size", size);
            class_2499 list = new class_2499();
            for (int i = 0; i < size; i++) {
                class_1799 stack = items.get(i);
                // Can't encode ItemStack.EMPTY - see NOTES.md
                if (stack == null || stack.method_7960()) continue;
                class_2487 entry = (class_2487) stack.method_57358(registries);
                entry.method_10569("Slot", i);
                list.add(entry);
            }
            nbt.method_10566("Items", list);
            return nbt;
        }
        @Override public List<class_1799> createStacks(class_3218 world, class_243 origin, class_3222 player, long fallbackSeed, int listSize, class_7225.class_7874 registries) {
            List<class_1799> out = new ArrayList<>(listSize);
            for (int i = 0; i < listSize; i++) out.add(i < items.size() ? items.get(i).method_7972() : class_1799.field_8037);
            return out;
        }
    }
}
